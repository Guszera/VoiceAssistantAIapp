package com.example.voiceassistantaiapp;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;

public class VoiceRecognitionService extends Service {

    private static final String CHANNEL_ID = "VoiceRecognitionServiceChannel";
    private static final int NOTIFICATION_ID = 1;

    private SpeechRecognizer speechRecognizer;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForegroundService();

        // Start wake word detection and speech recognition
        startListeningForWakeWord();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopListening();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void startForegroundService() {
        // Create a notification with a moving icon
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_moving_icon)
                .setContentTitle("Listening for Voice Input")
                .setContentText("App is actively listening for voice input")
                .setContentIntent(getPendingIntent())
                .build();

        startForeground(NOTIFICATION_ID, notification);
    }

    private PendingIntent getPendingIntent() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        return PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
    }

    private void startListeningForWakeWord() {
        // Implement wake word detection logic
        // This could involve analyzing audio data in real-time
        // and triggering an event when the wake word is detected
        // For simplicity, we'll assume the wake word is detected immediately
        // In a real-world scenario, you would use a dedicated library or algorithm for this task

        // For demonstration purposes, let's assume the wake word is "hello"
        if ("hello".equalsIgnoreCase("wake up word")) {
            // Wake word detected, start speech recognition
            startSpeechRecognition();
        }
    }

    private void startSpeechRecognition() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                // Called when the recognizer is ready to start listening
            }

            @Override
            public void onBeginningOfSpeech() {
                // Called when the user starts to speak
            }

            @Override
            public void onRmsChanged(float rmsdB) {
                // Called when the RMS value of the audio being processed changes
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
                // Called after the user stops speaking, and the recognizer is processing the audio
            }

            @Override
            public void onEndOfSpeech() {
                // Called when the user finishes speaking
                // Restart the speech recognition process
                startSpeechRecognition();
            }

            @Override
            public void onError(int error) {
                // Called when an error occurs during recognition
            }

            @Override
            public void onResults(Bundle results) {
                // Called when recognition results are available
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    // Process recognized text
                    String recognizedText = matches.get(0);
                    performActionBasedOnText(recognizedText);
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                // Called when partial recognition results are available
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
                // Called when events related to the recognition are available
            }
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);

        speechRecognizer.startListening(intent);
    }

    private void stopListening() {
        if (speechRecognizer != null) {
            speechRecognizer.stopListening();
            speechRecognizer.destroy();
        }
        stopForeground(true);
        stopSelf();
    }

    private void performActionBasedOnText(String text) {
        // Implement actions based on the recognized text
        // For example, you might launch specific activities or perform tasks
    }
}